<template>
  <div class="container">
    <div class="title"><span>小白有品</span></div>
    <div>
      <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
        <van-swipe-item><img src="../assets/images/1.png" /></van-swipe-item>
        <van-swipe-item><img src="../assets/images/2.png" /></van-swipe-item>
        <van-swipe-item><img src="../assets/images/3.png" /></van-swipe-item>
        <van-swipe-item><img src="../assets/images/4.png" /></van-swipe-item>
        <van-swipe-item><img src="../assets/images/5.jpg" /></van-swipe-item>
        <van-swipe-item><img src="../assets/images/6.png" /></van-swipe-item>
      </van-swipe>
    </div>
    <div>
      <ul>
        <li>
          <img src="../assets/images/7.png" />
          <p>优惠商品</p>
        </li>
        <li>
          <img src="../assets/images/8.png" />
          <p>畅销爆款</p>
        </li>
        <li>
          <img src="../assets/images/9.png" />
          <p>AI录音笔</p>
        </li>
        <li>
          <img src="../assets/images/10.png" />
          <p>糖猫手表</p>
        </li>
      </ul>
      <ul>
        <li>
          <img src="../assets/images/11.png" />
          <p>糖猫词典笔</p>
        </li>
        <li>
          <img src="../assets/images/12.png" />
          <p>智能配件</p>
        </li>
        <li>
          <img src="../assets/images/13.png" />
          <p>搜狗S码</p>
        </li>
        <li>
          <img src="../assets/images/14.png" />
          <p>全部商品</p>
        </li>
      </ul>
    </div>
    <div>
      <div class="new">
        <h4>上新精选</h4>
        <p>更多</p>
      </div>
      <div class="jingxuan">
        <div id="a1">
          <img src="../assets/images/15.png" />
          <p>云米洗烘一体机</p>
        </div>
        <div id="a1">
          <img src="../assets/images/16.png" />
          <p>早春明前绿茶</p>
        </div>
        <div id="a1">
          <img src="../assets/images/17.png" />
          <p>智能静音止鼾枕</p>
        </div>
        <div id="a1">
          <img src="../assets/images/18.png" />
          <p>15W无线快充</p>
        </div>
        <div id="a1">
          <img src="../assets/images/19.png" />
          <p>多功能电饭煲</p>
        </div>
        <div id="a1">
          <img src="../assets/images/20.png" />
          <p>65W插线板</p>
        </div>
        <div id="a1">
          <img src="../assets/images/21.png" />
          <p>无线降噪耳机</p>
        </div>
        <div id="a1">
          <img src="../assets/images/22.png" />
          <p>冰封散热背夹</p>
        </div>
        <div id="a1">
          <img src="../assets/images/23.png" />
          <p>智能升降烤锅</p>
        </div>
        <div id="a1">
          <img src="../assets/images/24.png" />
          <p>激光测距仪</p>
        </div>
      </div>
    </div>
  </div>
</template>
<style scoped>
* {
  margin: 0;
  padding: 0;
}
/* .container {
  background: #ddd;
} */
.title {
  background: pink;
  color: white;
  font-size: 1.3rem;
  font-weight: 700;
  height: 40px;
  line-height: 40px;
}
.my-swipe .van-swipe-item {
  color: #fff;
  font-size: 20px;
  /* line-height: 150px; */
  text-align: center;
}
.my-swipe .van-swipe-item img {
  width: 100%;
}
ul {
  width: 100%;
  background-color: #ccc;
  margin: auto;
  text-align: center;
  color: #666;
  font-size: 12px;
  display: flex;
  justify-content: space-around;
  list-style: none;
}
li {
  padding: 5px;
}
li img {
  width: 60px;
}
.jingxuan {
  float: left;
  display: flex;
  width: 100%;
  overflow: scroll;
  margin-top: 5px;
  background-color: rgba(233, 233, 233, 0.2);
}
.jingxuan::-webkit-scrollbar {
  display: none;
}
.jingxuan img {
  width: 100px;
}
.jingxuan p {
  font-size: 12px;
}
.jingxuan div {
  background-color: rgb(252, 247, 241);
  margin: 0 5px;
}
.new {
  display: flex;
  justify-content: space-between;
}
.new p {
  font-size: 14px;
  color: #aaa;
  margin-top: 3px;
}
</style>